﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StockUpdateApp.Models
{
    class StockServices
    {
        private static List<Stocks> objStockList;
        public StockServices()
        {
            objStockList = new List<Stocks>(){
                new Stocks {StockId=101,StockName="TataMotors",StockDate="2020/02/21" }
            };
        }

        public  List<Stocks> GetAll()
        {
            return objStockList;
        }
        public bool Add(Stocks objNewStocks)
        {
            objStockList.Add(objNewStocks);
            return true;
        }
        public bool Update(Stocks objStockToUpdate)
        {
            bool IsUpdated = false;
            for(int index = 0; index < objStockList.Count; index++)
            {
                if (objStockList[index].StockId == objStockToUpdate.StockId)
                {
                    objStockList[index].StockName = objStockToUpdate.StockName;
                    objStockList[index].StockDate = objStockToUpdate.StockDate;
                    IsUpdated = true;
                    break;
                }
            }
            return IsUpdated;
        }
        public bool Delete(int id)
        {
            bool IsDeleted = false;
            for(int index = 0; index < objStockList.Count; index++)
            {
                if (objStockList[index].StockId == id)
                {
                    objStockList.RemoveAt(index);
                    IsDeleted = true;
                    break;
                }
            }
            return IsDeleted;
        }
        public Stocks Search(int id)
        {
            return objStockList.FirstOrDefault(s => s.StockId == id);
        }
    }
}

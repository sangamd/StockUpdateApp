﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;

namespace StockUpdateApp.Models
{
    class Stocks : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        private void OnStockChanged(string stockName)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(stockName));
        }
        private int stockId;

        public int StockId
        {
            get { return stockId; }
            set { stockId = value;OnStockChanged("stockId"); }
        }
        private string stockName;

        public string StockName
        {
            get { return stockName; }
            set { stockName = value;OnStockChanged("stockName"); }
        }

        private string stockDate;

        public string StockDate
        {
            get { return stockDate; }
            set { stockDate = value;OnStockChanged("stockDate"); }
        }




    }
}
